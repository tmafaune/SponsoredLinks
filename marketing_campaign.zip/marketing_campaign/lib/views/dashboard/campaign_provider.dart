import 'package:flutter/material.dart';
import 'package:marketing_campaign/models/campaign_model.dart';


class CampaignProvider with ChangeNotifier {
  List<Campaign> _campaigns = [];

  List<Campaign> get campaigns => _campaigns;

  void addCampaign(Campaign campaign) {
    _campaigns.add(campaign);
    notifyListeners();
  }

  void deleteCampaign(Campaign campaign) {
    _campaigns.remove(campaign);
    notifyListeners();
  }
}