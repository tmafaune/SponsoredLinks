import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:go_router/go_router.dart';
import 'package:intl/intl.dart';
import 'package:marketing_campaign/models/user_model.dart';
import 'package:marketing_campaign/widgets/theme_switcher.dart';
import 'package:provider/provider.dart';
import 'package:marketing_campaign/services/theme_service.dart';
import 'package:marketing_campaign/models/campaign_model.dart';
import 'package:marketing_campaign/views/dashboard/campaign_provider.dart';

class DashboardScreen extends StatelessWidget {
  final User user;
  const DashboardScreen({super.key, required this.user});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Marketing Dashboard'),
        leading: Builder(
          builder: (context) => IconButton(
            icon: const Icon(Icons.menu),
            onPressed: () => Scaffold.of(context).openDrawer(),
          ),
        ),
      ),
      drawer: Drawer(
        child: ListView(
          padding: EdgeInsets.zero,
          children: [
            UserAccountsDrawerHeader(
              accountName: Text(user.name),
              accountEmail: Text(user.contact),
              currentAccountPicture: CircleAvatar(child: Icon(Icons.person)),
            ),
            ListTile(
              leading: Icon(Icons.settings),
              title: Text('Account Management'),
              onTap: () => context.push('/account-management'),
            ),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
              child: ThemeToggleButton(),
            ),
            ListTile(
              leading: Icon(Icons.exit_to_app),
              title: Text('Logout'),
              onTap: () => context.read<ThemeService>().logout(),
            ),
          ],
        ),
      ),
      body: LayoutBuilder(
        builder: (context, constraints) {
          final baseSize = MediaQuery.of(context).size.width * 0.02;
          final cardRadius = MediaQuery.of(context).size.width * 0.05;
          final avatarRadius = MediaQuery.of(context).size.width * 0.05;
          final subtitleSize = baseSize * 0.8;
          final titleSize = baseSize * 1.9;

          return Consumer<CampaignProvider>(
            builder: (context, provider, child) {
              return Center(
                child: ConstrainedBox(
                  constraints: BoxConstraints(maxWidth: 1200),
                  child: provider.campaigns.isEmpty
                      ? Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Icon(Icons.campaign, size: 80),
                            SizedBox(height: 20),
                            Text('No campaigns yet',
                                style: Theme.of(context)
                                    .textTheme
                                    .headlineSmall
                                    ?.copyWith(fontSize: baseSize * 1.9)),
                          ],
                        )
                      : ListView.builder(
                          padding: EdgeInsets.all(16),
                          itemCount: provider.campaigns.length,
                          itemBuilder: (context, index) {
                            final campaign = provider.campaigns[index];
                            return Card(
                              elevation: 2,
                              margin: EdgeInsets.symmetric(vertical: 8),
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(12),
                              ),
                              child: ListTile(
                                leading: CircleAvatar(
                                  radius: avatarRadius,
                                  backgroundImage: campaign.bannerImage != null
                                      ? FileImage(campaign.bannerImage!)
                                      : NetworkImage(campaign.bannerUrl),
                                  child: campaign.bannerImage == null &&
                                          campaign.bannerUrl.isEmpty
                                      ? Icon(Icons.link, size: avatarRadius * 0.6)
                                      : null,
                                ),
                                title: Text(
                                  campaign.ownerName,
                                  style: TextStyle(fontSize: titleSize),
                                ),
                                subtitle: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text(
                                      'Start: ${DateFormat('dd MMM').format(campaign.startDate)}',
                                      style: TextStyle(fontSize: subtitleSize),
                                    ),
                                    Text(
                                      'End: ${DateFormat('dd MMM').format(campaign.endDate)}',
                                      style: TextStyle(fontSize: subtitleSize),
                                    ),
                                  ],
                                ),
                                trailing: IconButton(
                                  icon: Icon(Icons.arrow_forward_ios, size: avatarRadius * 0.4),
                                  onPressed: () => _showCampaignDetails(context, campaign),
                                ),
                              ),
                            );
                          },
                        ),
                ),
              );
            },
          );
        },
      ),
      bottomNavigationBar: BottomNavigationBar(
        type: BottomNavigationBarType.fixed,
        items: const [
          BottomNavigationBarItem(
            icon: Icon(Icons.home),
            label: 'Home',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.add),
            label: 'New Campaign',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.manage_accounts),
            label: 'Manage',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.analytics),
            label: 'Analytics',
          ),
        ],
        currentIndex: 0,
        onTap: (index) {
          switch (index) {
            case 0:
              context.go('/dashboard');
              break;
            case 1:
              context.push('/launch-campaign');
              break;
            case 2:
              context.push('/manage-campaigns');
              break;
            case 3:
              context.push('/analytics');
              break;
          }
        },
      ),
    );
  }

  void _showCampaignDetails(BuildContext context, Campaign campaign) {
    final screenHeight = MediaQuery.of(context).size.height;
    final baseFontSize = screenHeight * 0.015;
    
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      builder: (context) => Container(
        padding: EdgeInsets.all(16),
        constraints: BoxConstraints(maxHeight: screenHeight * 0.6),
        child: MediaQuery(
          data: MediaQuery.of(context).copyWith(textScaleFactor: 0.9),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Text('Campaign Details',
                  style: TextStyle(
                    fontSize: baseFontSize * 1.5,
                    fontWeight: FontWeight.bold
                  )),
              SizedBox(height: 12),
              ListTile(
                contentPadding: EdgeInsets.zero,
                leading: Icon(Icons.link, size: baseFontSize * 1.2),
                title: Text('Unique Link',
                    style: TextStyle(fontSize: baseFontSize)),
                subtitle: SelectableText(campaign.landingUrl,
                    style: TextStyle(fontSize: baseFontSize * 0.8)),
              ),
              ListTile(
                contentPadding: EdgeInsets.zero,
                leading: Icon(Icons.attach_money, size: baseFontSize * 1.2),
                title: Text('CPC',
                    style: TextStyle(fontSize: baseFontSize)),
                subtitle: Text('\$${campaign.cpc.toStringAsFixed(2)}',
                    style: TextStyle(fontSize: baseFontSize * 0.8)),
              ),
              Row(
                mainAxisAlignment: MainAxisAlignment.end,
                children: [
                  TextButton(
                    onPressed: () {
                      Clipboard.setData(ClipboardData(text: campaign.landingUrl));
                      ScaffoldMessenger.of(context).showSnackBar(
                        SnackBar(content: Text('Link copied to clipboard!')),
                      );
                    },
                    child: Text('Copy Link',
                        style: TextStyle(fontSize: baseFontSize * 0.9)),
                  ),
                  SizedBox(width: 8),
                  TextButton(
                    onPressed: () {
                      context.read<CampaignProvider>().deleteCampaign(campaign);
                      Navigator.pop(context);
                    },
                    child: Text('Delete Campaign',
                        style: TextStyle(fontSize: baseFontSize * 0.9)),
                  ),
                ],
              )
            ],
          ),
        ),
      ),
    );
  }
}