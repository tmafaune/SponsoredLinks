import 'package:flutter/material.dart';
import 'package:marketing_campaign/utils/constants.dart';
import 'package:marketing_campaign/widgets/campaign_card.dart';
import 'package:marketing_campaign/widgets/custom_appbar.dart';
import 'package:marketing_campaign/models/campaign_model.dart';
import 'package:go_router/go_router.dart'; // Add this import

class CampaignManagementScreen extends StatelessWidget {
  final List<Campaign> campaigns = [];
  CampaignManagementScreen({super.key}); // Replace with real data

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: const CustomAppBar(title: 'Active Campaigns', showBackButton: true),
      body: Padding(
        padding: AppPadding.kPagePadding,
        child: campaigns.isEmpty
            ? const Center(
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Icon(Icons.campaign_outlined, size: 80, color: AppColors.kGrey),
                    SizedBox(height: 20),
                    Text('No Active Campaigns', style: TextStyles.kHeadingStyle),
                    SizedBox(height: 10),
                    Text('Launch your first campaign to get started', 
                      style: TextStyles.kBodyStyle),
                  ],
                ),
              )
            : ListView.builder(
                itemCount: campaigns.length,
                itemBuilder: (context, index) => CampaignCard(
                  campaign: campaigns[index],
                  onEdit: () => _editCampaign(context, campaigns[index]),
                  onDelete: () => _deleteCampaign(campaigns[index]),
                ),
              ),
      ),
      bottomNavigationBar: BottomNavigationBar(
        type: BottomNavigationBarType.fixed,
        items: const [
          BottomNavigationBarItem(
            icon: Icon(Icons.home),
            label: 'Home',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.add),
            label: 'New Campaign',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.manage_accounts),
            label: 'Manage',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.analytics),
            label: 'Analytics',
          ),
        ],
        currentIndex: 2, // Manage is selected by default
        onTap: (index) {
          switch (index) {
            case 0:
              context.go('/dashboard');
              break;
            case 1:
              context.push('/launch-campaign');
              break;
            case 2:
              // Already on Manage screen
              break;
            case 3:
              context.push('/analytics');
              break;
          }
        },
      ),
    );
  }

  void _editCampaign(BuildContext context, Campaign campaign) {
    // Navigate to edit screen
  }

  void _deleteCampaign(Campaign campaign) {
    // Handle delete
  }
}