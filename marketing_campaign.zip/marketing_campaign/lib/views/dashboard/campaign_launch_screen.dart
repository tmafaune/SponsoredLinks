import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:marketing_campaign/models/campaign_model.dart';
import 'package:marketing_campaign/widgets/image_upload_section.dart';
import 'package:marketing_campaign/widgets/date_picker_field.dart';
import 'package:marketing_campaign/utils/validators.dart';
import 'package:marketing_campaign/widgets/custom_appbar.dart';
import 'dart:io';
import 'package:intl/intl.dart';
import 'package:provider/provider.dart';
import 'package:marketing_campaign/views/dashboard/campaign_provider.dart';

class CampaignLaunchScreen extends StatefulWidget {
  const CampaignLaunchScreen({super.key});

  @override
  _CampaignLaunchScreenState createState() => _CampaignLaunchScreenState();
}

class _CampaignLaunchScreenState extends State<CampaignLaunchScreen> {
  final _formKey = GlobalKey<FormState>();
  final _urlController = TextEditingController();
  final _cpcController = TextEditingController();
  DateTime? _startDate;
  DateTime? _endDate;
  File? _bannerImage;

  void _submitForm() {
    if (_formKey.currentState!.validate()) {
      if (Validators.validateDate(_startDate) != null) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Start date is required and cannot be in the past.')),
        );
        return;
      }
      if (Validators.validateDate(_endDate) != null ||
          (_endDate != null && _endDate!.isBefore(_startDate!))) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('End date must be after start date and cannot be in the past.')),
        );
        return;
      }
      showDialog(
        context: context,
        builder: (context) => _VerificationDialog(
          bannerImage: _bannerImage,
          url: _urlController.text,
          startDate: _startDate,
          endDate: _endDate,
          cpc: _cpcController.text,
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: const CustomAppBar(title: 'Launch Campaign'),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Form(
          key: _formKey,
          child: ListView(
            children: [
              ImageUploadSection(
                onImageSelected: (image) => _bannerImage = image,
              ),
              const SizedBox(height: 20),
              TextFormField(
                controller: _urlController,
                decoration: InputDecoration(
                  labelText: 'Landing Page URL',
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(12),
                  ),
                ),
                validator: Validators.validateUrl,
              ),
              const SizedBox(height: 20),
              DatePickerField(
                label: 'Start Date',
                selectedDate: _startDate,
                onTap: () async {
                  final date = await showDatePicker(
                    context: context,
                    initialDate: DateTime.now(),
                    firstDate: DateTime.now(),
                    lastDate: DateTime(DateTime.now().year + 1),
                  );
                  if (date != null) {
                    setState(() => _startDate = date);
                  }
                },
              ),
              const SizedBox(height: 20),
              DatePickerField(
                label: 'End Date',
                selectedDate: _endDate,
                onTap: () async {
                  final date = await showDatePicker(
                    context: context,
                    initialDate: _startDate ?? DateTime.now(),
                    firstDate: _startDate ?? DateTime.now(),
                    lastDate: DateTime(DateTime.now().year + 1),
                  );
                  if (date != null) {
                    setState(() => _endDate = date);
                  }
                },
              ),
              const SizedBox(height: 20),
              TextFormField(
                controller: _cpcController,
                decoration: InputDecoration(
                  labelText: 'Cost Per Click (CPC)',
                  prefixText: '\$ ',
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(12),
                  ),
                ),
                keyboardType: TextInputType.number,
                validator: Validators.validateCPC,
              ),
              const SizedBox(height: 20),
              ElevatedButton(
                onPressed: _submitForm,
                style: ElevatedButton.styleFrom(
                  padding: const EdgeInsets.symmetric(vertical: 16),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(12),
                  ),
                ),
                child: const Text('Activate Campaign'),
              ),
            ],
          ),
        ),
      ),
      bottomNavigationBar: BottomNavigationBar(
        type: BottomNavigationBarType.fixed,
        items: const [
          BottomNavigationBarItem(
            icon: Icon(Icons.home),
            label: 'Home',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.add),
            label: 'New Campaign',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.manage_accounts),
            label: 'Manage',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.analytics),
            label: 'Analytics',
          ),
        ],
        currentIndex: 1, // New Campaign is selected by default
        onTap: (index) {
          switch (index) {
            case 0:
              context.go('/dashboard');
              break;
            case 1:
              // Already on New Campaign page
              break;
            case 2:
              context.push('/manage-campaigns');
              break;
            case 3:
              context.push('/analytics');
              break;
          }
        },
      ),
    );
  }
}

class _VerificationDialog extends StatelessWidget {
  final File? bannerImage;
  final String url;
  final DateTime? startDate;
  final DateTime? endDate;
  final String cpc;

  const _VerificationDialog({
    required this.bannerImage,
    required this.url,
    required this.startDate,
    required this.endDate,
    required this.cpc,
  });

  @override
  Widget build(BuildContext context) {
 // Responsive configuration
    final screenWidth = MediaQuery.of(context).size.width;
    final screenHeight = MediaQuery.of(context).size.height;

    // Text scaling configuration (adjust these values)
    final baseFontSize = screenWidth * 0.025; // 2.5% of screen width
    final buttonFontSize = baseFontSize * 1.3; // 30% larger than base
    final labelFontSize = baseFontSize * 1.1; // 10% larger than base
    final valueFontSize = baseFontSize * 1.0;

    return AlertDialog(
      title: Text('Verify Campaign Details',
        style: TextStyle(
          fontSize: baseFontSize * 1.8, // 80% larger than base
          fontWeight: FontWeight.bold,
        ),
        textAlign: TextAlign.center,
      ),
      contentPadding: EdgeInsets.zero,
      content: ConstrainedBox(
        constraints: BoxConstraints(maxHeight: screenHeight * 0.6),
        child: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              if (bannerImage != null)
                ClipRRect(
                  borderRadius: BorderRadius.circular(12),
                  child: SizedBox(
                    height: screenHeight * 0.25, // 25% of screen height
                    child: AspectRatio(
                      aspectRatio: 16/9,
                      child: Image.file(bannerImage!, fit: BoxFit.cover),
                    ),
                  ),
                ),
              if (bannerImage != null) SizedBox(height: 20),
              _ResponsiveDetailRow(
                label: 'URL',
                value: url,
                labelStyle: TextStyle(fontSize: labelFontSize),
                valueStyle: TextStyle(fontSize: valueFontSize),
              ),
              _ResponsiveDetailRow(
                label: 'Start Date',
                value: startDate != null 
                  ? DateFormat('dd/MM/yyyy').format(startDate!) 
                  : 'Not set',
                labelStyle: TextStyle(fontSize: labelFontSize),
                valueStyle: TextStyle(fontSize: valueFontSize),
              ),
              _ResponsiveDetailRow(
                label: 'End Date',
                value: endDate != null 
                  ? DateFormat('dd/MM/yyyy').format(endDate!) 
                  : 'Not set',
                labelStyle: TextStyle(fontSize: labelFontSize),
                valueStyle: TextStyle(fontSize: valueFontSize),
              ),
              _ResponsiveDetailRow(
                label: 'CPC',
                value: '\$$cpc',
                labelStyle: TextStyle(fontSize: labelFontSize),
                valueStyle: TextStyle(fontSize: valueFontSize),
              ),
            ],
          ),
        ),
      ),
      actions: [
        TextButton(
          onPressed: () => Navigator.pop(context),
          style: ButtonStyle(
            padding: MaterialStateProperty.all(EdgeInsets.symmetric(
              vertical: 16,
              horizontal: 24,
            )),
          ),
          child: Text('Cancel', 
            style: TextStyle(
              fontSize: buttonFontSize,
              fontWeight: FontWeight.bold,
            ),
          ),
        ),
        ElevatedButton(
          onPressed: () {
            final provider = context.read<CampaignProvider>();
            final newCampaign = Campaign(
              id: DateTime.now().toString(),
              ownerName: url.split('/').last,
              bannerUrl: url,
              startDate: startDate!,
              endDate: endDate!,
              cpc: double.tryParse(cpc) ?? 0.0,
              budget: 0.0,
              landingUrl: 'https://yourdomain.com/campaign/${DateTime.now().millisecondsSinceEpoch}', title: '',
            );
            provider.addCampaign(newCampaign);
            Navigator.pop(context);
            context.go('/dashboard');
          },
          child: const Text('Confirm'),
        ),
      ],
    );
  }
}

class _ResponsiveDetailRow extends StatelessWidget {
  final String label;
  final String value;
  final TextStyle labelStyle;
  final TextStyle valueStyle;

  const _ResponsiveDetailRow({
    required this.label,
    required this.value,
    this.labelStyle = const TextStyle(),
    this.valueStyle = const TextStyle(),
  });

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Expanded(
            flex: 3,
            child: Text(
              label,
              style: labelStyle.copyWith(fontWeight: FontWeight.bold),
              overflow: TextOverflow.ellipsis,
              maxLines: 1,
            ),
          ),
          const SizedBox(width: 16),
          Expanded(
            flex: 7,
            child: Text(
              value,
              style: valueStyle,
              overflow: TextOverflow.ellipsis,
              maxLines: 1,
            ),
          ),
        ],
      ),
    );
  }
}