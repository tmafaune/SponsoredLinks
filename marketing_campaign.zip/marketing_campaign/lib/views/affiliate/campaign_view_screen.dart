import 'package:flutter/material.dart';
import 'package:marketing_campaign/models/campaign_model.dart';
import 'package:marketing_campaign/widgets/custom_appbar.dart';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:marketing_campaign/utils/constants.dart';

class CampaignViewScreen extends StatelessWidget {
  final String campaignId;
  final List<Campaign> campaigns = []; // Replace with actual data source

   CampaignViewScreen({
    super.key,
    required this.campaignId,
  });

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: const CustomAppBar(title: 'Available Campaigns'),
      body: Padding(
        padding: AppPadding.kPagePadding,
        child: GridView.builder(
          gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
            crossAxisCount: 2,
            crossAxisSpacing: 15,
            mainAxisSpacing: 15,
            childAspectRatio: 0.8,
          ),
          itemCount: campaigns.length,
          itemBuilder: (context, index) => _CampaignTile(
            campaign: campaigns[index],
            onTap: () => _showCampaignDetails(context, campaigns[index]),
          ),
        ),
      ),
    );
  }

  void _showCampaignDetails(BuildContext context, Campaign campaign) {
    showModalBottomSheet(
      context: context,
      builder: (context) => Padding(
        padding: AppPadding.kPagePadding,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(campaign.title, style: TextStyles.kHeadingStyle),
            const SizedBox(height: 16),
            CachedNetworkImage(
              imageUrl: campaign.bannerUrl,
              height: 200,
              width: double.infinity,
              fit: BoxFit.cover,
            ),
            const SizedBox(height: 16),
            _buildDetailRow('Organizer', campaign.ownerName),
            _buildDetailRow('CPC Rate', '\$${campaign.cpc}/click'),
            _buildDetailRow('Total Budget', '\$${campaign.budget}'),
            const Spacer(),
            SizedBox(
              width: double.infinity,
              child: ElevatedButton(
                onPressed: () => _joinCampaign(campaign.id),
                child: const Text('Join Campaign'),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildDetailRow(String label, String value) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(label, style: TextStyles.kBodyStyle),
          Text(value, style: TextStyles.kBodyBoldStyle),
        ],
      ),
    );
  }

  void _joinCampaign(String campaignId) {
    // Implement campaign joining logic
  }
}

class _CampaignTile extends StatelessWidget {
  final Campaign campaign;
  final VoidCallback onTap;

  const _CampaignTile({
    required this.campaign,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return Card(
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15)),
      child: InkWell(
        borderRadius: BorderRadius.circular(15),
        onTap: onTap,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Expanded(
              child: ClipRRect(
                borderRadius: const BorderRadius.vertical(top: Radius.circular(15)),
                child: CachedNetworkImage(
                  imageUrl: campaign.bannerUrl,
                  fit: BoxFit.cover,
                  placeholder: (context, url) => Container(color: AppColors.kGrey),
                ),
              ),
            ),
            Padding(
              padding: const EdgeInsets.all(12),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(campaign.ownerName, style: TextStyles.kSmallBoldStyle),
                  const SizedBox(height: 4),
                  Text(campaign.title,
                      style: TextStyles.kBodyStyle,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis),
                  const SizedBox(height: 8),
                  Row(
                    children: [
                      const Icon(Icons.monetization_on_outlined,
                          size: 16, color: AppColors.kYellow),
                      const SizedBox(width: 4),
                      Text('\$${campaign.cpc}/click', style: TextStyles.kSmallStyle),
                    ],
                  ),
                ],
              ),
            )
          ],
        ),
      ),
    );
  }
}