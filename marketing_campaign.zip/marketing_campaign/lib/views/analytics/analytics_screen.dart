import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';

// Define CampaignData class outside AnalyticsScreen
class CampaignData {
  final String name;
  final int clicks;
  final int totalCV;
  final double revenue;
  final String cvr;

  CampaignData({
    required this.name,
    required this.clicks,
    required this.totalCV,
    required this.revenue,
    required this.cvr,
  });
}

class AnalyticsScreen extends StatelessWidget {
   AnalyticsScreen({super.key});

  // Sample data
  final List<CampaignData> _campaigns = [
    CampaignData(name: "Spring Sale with Extra Discounts", clicks: 1500, totalCV: 250, revenue: 3750.50, cvr: "16.7%"),
    CampaignData(name: "Summer Promo for Limited Time", clicks: 890, totalCV: 150, revenue: 2200.00, cvr: "17.5%"),
    CampaignData(name: "Black Friday Mega Event", clicks: 3200, totalCV: 480, revenue: 8400.75, cvr: "15.0%"),
    CampaignData(name: "Winter Clearance Sale", clicks: 1200, totalCV: 200, revenue: 3000.00, cvr: "16.7%"),
    CampaignData(name: "Holiday Special Offers", clicks: 2000, totalCV: 300, revenue: 4500.00, cvr: "15.0%"),
    CampaignData(name: "Flash Sale - Last Chance", clicks: 900, totalCV: 140, revenue: 2100.00, cvr: "15.6%"),
    CampaignData(name: "Back to School Supplies", clicks: 1800, totalCV: 280, revenue: 4200.00, cvr: "15.6%"),
    CampaignData(name: "Cyber Monday Extravaganza", clicks: 2500, totalCV: 400, revenue: 6000.00, cvr: "16.0%"),
    CampaignData(name: "End of Season Clearance", clicks: 1000, totalCV: 160, revenue: 2400.00, cvr: "16.0%"),
    CampaignData(name: "Year-End Offer Bonanza", clicks: 1400, totalCV: 220, revenue: 3300.00, cvr: "15.7%"),
    CampaignData(name: "Special Event with Exclusive Deals", clicks: 1600, totalCV: 260, revenue: 3900.00, cvr: "16.3%"),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Analytics')),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: ListView.builder(
          itemCount: _campaigns.length,
          itemBuilder: (context, index) {
            final campaign = _campaigns[index];
            return Card(
              elevation: 4,
              margin: const EdgeInsets.symmetric(vertical: 8),
              child: Padding(
                padding: const EdgeInsets.all(16.0),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      campaign.name,
                      style: const TextStyle(
                        fontWeight: FontWeight.bold,
                        fontSize: 16,
                      ),
                    ),
                    const SizedBox(height: 8),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        _buildInfoItem("Clicks", campaign.clicks.toString()),
                        _buildInfoItem("Total CV", campaign.totalCV.toString()),
                        _buildInfoItem("Rev", "\$${campaign.revenue.toStringAsFixed(2)}"),
                        _buildInfoItem("CVR", campaign.cvr),
                      ],
                    ),
                  ],
                ),
              ),
            );
          },
        ),
      ),
      bottomNavigationBar: BottomNavigationBar(
        type: BottomNavigationBarType.fixed,
        items: const [
          BottomNavigationBarItem(icon: Icon(Icons.home), label: 'Home'),
          BottomNavigationBarItem(icon: Icon(Icons.add), label: 'New Campaign'),
          BottomNavigationBarItem(icon: Icon(Icons.manage_accounts), label: 'Manage'),
          BottomNavigationBarItem(icon: Icon(Icons.analytics), label: 'Analytics'),
        ],
        currentIndex: 3,
        onTap: (index) {
          switch (index) {
            case 0:
              context.go('/dashboard');
              break;
            case 1:
              context.push('/launch-campaign');
              break;
            case 2:
              context.push('/manage-campaigns');
              break;
            case 3:
              break; // Already on Analytics
          }
        },
      ),
    );
  }

  Widget _buildInfoItem(String label, String value) {
    return Column(
      children: [
        Text(
          label,
          style: const TextStyle(fontSize: 12, color: Colors.grey),
        ),
        Text(
          value,
          style: const TextStyle(fontSize: 14, fontWeight: FontWeight.bold),
        ),
      ],
    );
  }
}