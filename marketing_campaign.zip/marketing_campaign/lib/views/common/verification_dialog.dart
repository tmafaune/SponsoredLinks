import 'package:flutter/material.dart';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:marketing_campaign/models/campaign_model.dart';
import 'package:marketing_campaign/utils/constants.dart';

class VerificationDialog extends StatelessWidget {
  final Campaign campaign;

  const VerificationDialog({required this.campaign, super.key});

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      title: const Text('Confirm Campaign Details', style: TextStyles.kDialogTitleStyle),
      content: SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _DetailRow('Campaign Title:', campaign.title),
            _DetailRow('Landing Page:', campaign.landingUrl),
            _DetailRow('Start Date:', campaign.formattedStartDate),
            _DetailRow('End Date:', campaign.formattedEndDate),
            _DetailRow('CPC Offer:', '\$${campaign.cpc.toStringAsFixed(2)}/click'),
            const SizedBox(height: 20),
            Container(
              width: double.infinity,
              height: 150,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(10),
                image: DecorationImage(
                  fit: BoxFit.cover,
                  image: CachedNetworkImageProvider(campaign.bannerUrl),
                ),
              ),
            )
          ],
        ),
      ),
      actions: [
        TextButton(
          onPressed: () => Navigator.pop(context),
          child: const Text('Cancel', style: TextStyles.kDialogActionStyle),
        ),
        ElevatedButton(
          style: AppButtons.kPrimaryButtonStyle,
          onPressed: () => Navigator.pop(context, true),
          child: const Text('Confirm Activation'),
        ),
      ],
    );
  }
}

class _DetailRow extends StatelessWidget {
  final String label;
  final String value;

  const _DetailRow(this.label, this.value);

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          SizedBox(
            width: 100,
            child: Text(label, style: TextStyles.kBodyBoldStyle),
          ),
          const SizedBox(width: 10),
          Expanded(child: Text(value, style: TextStyles.kBodyStyle)),
        ],
      ),
    );
  }
}