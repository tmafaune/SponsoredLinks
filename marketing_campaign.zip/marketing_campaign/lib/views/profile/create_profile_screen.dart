import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'dart:io';

class CreateProfileScreen extends StatefulWidget {
  final Map<String, dynamic> registrationData;

  const CreateProfileScreen({
    super.key,
    required this.registrationData,
  });

  @override
  _CreateProfileScreenState createState() => _CreateProfileScreenState();
}

class _CreateProfileScreenState extends State<CreateProfileScreen> {
  int _currentStep = 0;
  final _formKey = GlobalKey<FormState>();
  final TextEditingController _nameController = TextEditingController();
  String? _location;
  final Set<String> _interests = {};
  File? _profilePicture;
  bool _isLoadingImage = false;

  Future<void> _pickProfilePicture() async {
    try {
      setState(() => _isLoadingImage = true);
      final pickedFile = await ImagePicker().pickImage(
        source: ImageSource.gallery,
        imageQuality: 85,
        maxWidth: 800,
      );

      if (pickedFile != null) {
        setState(() => _profilePicture = File(pickedFile.path));
      }
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Image selection failed: ${e.toString()}')),
      );
    } finally {
      setState(() => _isLoadingImage = false);
    }
  }

  void _handleStepContinue() {
    if (_currentStep == 0 && !_formKey.currentState!.validate()) return;
    if (_currentStep < 2) {
      setState(() => _currentStep++);
    } else {
      _submitForm();
    }
  }

  void _submitForm() {
    if (_formKey.currentState!.validate()) {
      // Combine registration data with profile data
      final completeData = {
        ...widget.registrationData,
        'fullName': _nameController.text,
        'profilePicture': _profilePicture?.path,
        'location': _location,
        'interests': _interests.toList(),
      };

      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Profile created for: ${completeData['email']}'),
          duration: const Duration(seconds: 2),
        ),
      );
      
      // TODO: Implement actual submission logic
      // Navigator.push(context, MaterialPageRoute(builder: (context) => NextScreen()));
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Complete Your Profile')),
      body: Form(
        key: _formKey,
        child: Stepper(
          currentStep: _currentStep,
          onStepContinue: _handleStepContinue,
          onStepCancel: () => setState(() => _currentStep--),
          controlsBuilder: (context, details) {
            return Padding(
              padding: const EdgeInsets.only(top: 16),
              child: Row(
                children: [
                  if (_currentStep > 0)
                    OutlinedButton(
                      onPressed: details.onStepCancel,
                      child: const Text('BACK'),
                    ),
                  const Spacer(),
                  ElevatedButton(
                    onPressed: details.onStepContinue,
                    child: Text(
                      _currentStep == 2 ? 'COMPLETE PROFILE' : 'NEXT',
                      style: const TextStyle(color: Colors.white),
                    ),
                  ),
                ],
              ),
            );
          },
          steps: [
            _buildBasicInfoStep(),
            _buildProfilePictureStep(),
            _buildOptionalDetailsStep(),
          ],
        ),
      ),
    );
  }

  Step _buildBasicInfoStep() {
    return Step(
      isActive: _currentStep >= 0,
      title: const Text('Basic Info'),
      content: Column(
        children: [
          // Display registration email (non-editable)
          ListTile(
            title: const Text('Registered Email'),
            subtitle: Text(widget.registrationData['email']),
            leading: const Icon(Icons.email),
          ),
          const SizedBox(height: 16),
          // Name input field
          TextFormField(
            controller: _nameController,
            decoration: const InputDecoration(
              labelText: 'Full Name',
              prefixIcon: Icon(Icons.person),
              border: OutlineInputBorder(),
            ),
            validator: (value) => value!.isEmpty ? 'Required field' : null,
          ),
        ],
      ),
    );
  }

  Step _buildProfilePictureStep() {
    return Step(
      isActive: _currentStep >= 1,
      title: const Text('Profile Picture'),
      content: Column(
        children: [
          const Text('Upload a profile photo'),
          const SizedBox(height: 20),
          GestureDetector(
            onTap: _isLoadingImage ? null : _pickProfilePicture,
            child: Stack(
              alignment: Alignment.center,
              children: [
                CircleAvatar(
                  radius: 60,
                  backgroundColor: Colors.grey.shade200,
                  backgroundImage: _profilePicture != null
                      ? FileImage(_profilePicture!)
                      : null,
                  child: _profilePicture == null
                      ? const Icon(Icons.camera_alt, size: 40, color: Colors.grey)
                      : null,
                ),
                if (_isLoadingImage)
                  const CircularProgressIndicator(),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Step _buildOptionalDetailsStep() {
    return Step(
      isActive: _currentStep >= 2,
      title: const Text('Additional Info'),
      content: Column(
        children: [
          DropdownButtonFormField<String>(
            value: _location,
            hint: const Text('Select your location'),
            items: ['New York', 'London', 'Paris', 'Tokyo']
                .map((loc) => DropdownMenuItem(
                      value: loc,
                      child: Text(loc),
                    ))
                .toList(),
            onChanged: (value) => setState(() => _location = value),
            decoration: const InputDecoration(
              border: OutlineInputBorder(),
              prefixIcon: Icon(Icons.location_on),
            ),
          ),
          const SizedBox(height: 16),
          ...['Traveling', 'Reading', 'Sports', 'Cooking'].map((interest) {
            return CheckboxListTile(
              title: Text(interest),
              value: _interests.contains(interest),
              onChanged: (selected) => setState(() {
                selected!
                    ? _interests.add(interest)
                    : _interests.remove(interest);
              }),
              controlAffinity: ListTileControlAffinity.leading,
              dense: true,
            );
          }),
        ],
      ),
    );
  }
}