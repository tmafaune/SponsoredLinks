import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:marketing_campaign/utils/constants.dart';
import 'package:marketing_campaign/widgets/custom_appbar.dart';
import 'package:marketing_campaign/utils/validators.dart';

class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});

  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final _formKey = GlobalKey<FormState>(); // Add form key
  final _usernameController = TextEditingController();
  final _passwordController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: const CustomAppBar(title: 'SPONSORED LINKS', showBackButton: false),
      body: Padding(
        padding: AppPadding.kPagePadding,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            // Logo Section
            Expanded(
              flex: 2, // Adjust flex value for spacing
              child: Center(
                child: Container(
                  decoration: BoxDecoration(
                    shape: BoxShape.circle, 
                    border: Border.all(
                      color: Colors.white,
                      width: 2,
                    ),
                    boxShadow: [
                      BoxShadow(
                        color: Colors.black.withOpacity(0.2),
                        spreadRadius: 2,
                        blurRadius: 5,
                      ),
                    ],
                  ),
                  child: ClipOval(
                    child: Image.asset(
                      'lib/assets/images/sponsored_logo.jpg',
                      height: MediaQuery.of(context).size.width * 0.3,// Responsive logo size
                      width: MediaQuery.of(context).size.width * 0.3, 
                      fit: BoxFit.cover,
                    ),
                  ),
                ),
              ),
            ),

            // Form Section
            Expanded(
              flex: 3, // Adjust flex value for spacing
              child: Form(
                key: _formKey,
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    TextFormField(
                      controller: _usernameController,
                      decoration: const InputDecoration(
                        labelText: 'Username',
                        prefixIcon: Icon(Icons.person_outline),
                        border: AppBorders.kInputBorder,
                      ),
                      validator: Validators.validateUsername,
                    ),
                    const SizedBox(height: 20),
                    TextFormField(
                      controller: _passwordController,
                      obscureText: true,
                      decoration: const InputDecoration(
                        labelText: 'Password',
                        prefixIcon: Icon(Icons.lock_outline),
                        border: AppBorders.kInputBorder,
                      ),
                      validator: Validators.validatePassword,
                    ),
                    const SizedBox(height: 30),
                    ElevatedButton(
                      onPressed: () {
                        if (_formKey.currentState!.validate()) {
                          context.go('/dashboard');
                        }
                      },
                      style: AppButtons.kPrimaryButtonStyle,
                      child: const Text('Login'),
                    ),
                    TextButton(
                      onPressed: () => context.go('/register'),
                      child: const Text('Create New Account', style: TextStyles.kLinkStyle),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}