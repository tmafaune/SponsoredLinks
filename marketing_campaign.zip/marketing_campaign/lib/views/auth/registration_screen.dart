import 'package:flutter/material.dart';
import 'package:marketing_campaign/widgets/custom_appbar.dart';
import 'package:go_router/go_router.dart';

class RegistrationScreen extends StatefulWidget {
  const RegistrationScreen({super.key});

  @override
  _RegistrationScreenState createState() => _RegistrationScreenState();
}

class _RegistrationScreenState extends State<RegistrationScreen> {
  final _formKey = GlobalKey<FormState>();
  final TextEditingController _emailController = TextEditingController();
  final TextEditingController _passwordController = TextEditingController();
  final TextEditingController _regNumberController = TextEditingController();
  String? _selectedCompanyType;

  // Handle registration submission
  // In _submitRegistration method
void _submitRegistration() {
  if (_formKey.currentState!.validate()) {
    // Replace Navigator.pushNamed with GoRouter's push
    context.push(
      '/create-profile',
      extra: <String, dynamic>{
        'email': _emailController.text.trim(),
        'regNumber': _regNumberController.text.trim(),
        'companyType': _selectedCompanyType ?? 'Not Specified',
      },
    );
  }
}

  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: 2,
      child: Scaffold(
        appBar: const CustomAppBar(title: 'Registration'),
        body: Form(
          key: _formKey,
          child: Column(
            children: [
              const TabBar(
                labelColor: Colors.blue,
                unselectedLabelColor: Colors.grey,
                indicatorColor: Colors.blue,
                tabs: [
                  Tab(text: 'Account Info'),
                  Tab(text: 'Business Info'),
                ],
              ),
              Expanded(
                child: TabBarView(
                  children: [
                    // Account Information Tab
                    _buildAccountInfoTab(),
                    // Business Information Tab
                    _buildBusinessInfoTab(),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildAccountInfoTab() {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(16.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          _buildEmailField(),
          const SizedBox(height: 16),
          _buildPasswordField(),
          const SizedBox(height: 24),
          _buildNavigationButton('Next', () {
            if (_formKey.currentState!.validate()) {
              DefaultTabController.of(context).animateTo(1);
            }
          }),
        ],
      ),
    );
  }

  Widget _buildBusinessInfoTab() {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(16.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          _buildRegistrationNumberField(),
          const SizedBox(height: 16),
          _buildCompanyTypeDropdown(),
          const SizedBox(height: 24),
          _buildSubmitButton(),
        ],
      ),
    );
  }

  Widget _buildEmailField() {
    return TextFormField(
      controller: _emailController,
      decoration: const InputDecoration(
        labelText: 'Email',
        border: OutlineInputBorder(),
        prefixIcon: Icon(Icons.email),
      ),
      keyboardType: TextInputType.emailAddress,
      validator: (value) {
        if (value == null || value.isEmpty) return 'Please enter your email';
        if (!RegExp(r'^[\w-\.]+@([\w-]+\.)+[\w-]{2,4}$').hasMatch(value)) {
          return 'Please enter a valid email';
        }
        return null;
      },
    );
  }

  Widget _buildPasswordField() {
    return TextFormField(
      controller: _passwordController,
      obscureText: true,
      decoration: const InputDecoration(
        labelText: 'Password',
        border: OutlineInputBorder(),
        prefixIcon: Icon(Icons.lock),
      ),
      validator: (value) {
        if (value == null || value.isEmpty) return 'Please enter a password';
        if (value.length < 8) return 'Password must be at least 8 characters';
        return null;
      },
    );
  }

  Widget _buildRegistrationNumberField() {
    return TextFormField(
      controller: _regNumberController,
      decoration: const InputDecoration(
        labelText: 'Registration Number',
        border: OutlineInputBorder(),
        prefixIcon: Icon(Icons.numbers),
      ),
      validator: (value) {
        if (value == null || value.isEmpty) {
          return 'Please enter your registration number';
        }
        return null;
      },
    );
  }

  Widget _buildCompanyTypeDropdown() {
    return DropdownButtonFormField<String>(
      value: _selectedCompanyType,
      decoration: const InputDecoration(
        labelText: 'Company Type',
        border: OutlineInputBorder(),
        prefixIcon: Icon(Icons.business),
      ),
      items: ['Retail', 'Wholesale', 'Service', 'Manufacturing']
          .map((type) => DropdownMenuItem(
                value: type,
                child: Text(type),
              ))
          .toList(),
      onChanged: (value) => setState(() => _selectedCompanyType = value),
      validator: (value) =>
          value == null ? 'Please select your company type' : null,
    );
  }

  Widget _buildNavigationButton(String text, VoidCallback onPressed) {
    return ElevatedButton(
      onPressed: onPressed,
      style: ElevatedButton.styleFrom(
        padding: const EdgeInsets.symmetric(vertical: 16),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(8),
        ),
      ),
      child: Text(text),
    );
  }

  Widget _buildSubmitButton() {
    return _buildNavigationButton('Complete Registration', _submitRegistration);
  }
}