// Updated theme.dart
import 'package:flutter/material.dart';
import 'package:marketing_campaign/utils/constants.dart';
import 'package:google_fonts/google_fonts.dart';

class AppTheme {
  static ThemeData lightTheme() => ThemeData(
        brightness: Brightness.light,
        primaryColor: AppColors.kPrimaryLight,
        colorScheme: ColorScheme.light(
          primary: AppColors.kPrimaryLight,
          secondary: AppColors.kSecondaryLight,
          surface: AppColors.kBackgroundLight,
          onPrimary: AppColors.kPrimaryForegroundLight,
          onSecondary: AppColors.kSecondaryForegroundLight,
          error: AppColors.kDestructiveLight,
          onError: AppColors.kDestructiveForegroundLight,
          background: AppColors.kBackgroundLight,
          onBackground: AppColors.kForegroundLight,
        ),
        textTheme: TextTheme(
          displaySmall: GoogleFonts.poppins(
            textStyle: TextStyles.kHeadingStyle.copyWith(
              color: AppColors.kForegroundLight,
              fontWeight: FontWeight.bold,
            ),
          ),
          bodyLarge: GoogleFonts.poppins(
            textStyle: TextStyles.kBodyStyle.copyWith(
              color: AppColors.kForegroundLight,
            ),
          ),
          bodyMedium: GoogleFonts.poppins(
            textStyle: TextStyles.kBodyStyle.copyWith(
              fontSize: 14,
              color: AppColors.kForegroundLight,
            ),
          ),
        ),
        inputDecorationTheme: InputDecorationTheme(
          border: AppBorders.kInputBorder,
          filled: true,
          fillColor: AppColors.kMutedLight,
          hintStyle: GoogleFonts.poppins(
            textStyle: TextStyles.kBodyStyle.copyWith(
              color: AppColors.kMutedForegroundLight,
            ),
          ),
        ),
        appBarTheme: AppBarTheme(
          backgroundColor: AppColors.kPrimaryLight,
          elevation: 2,
          iconTheme: const IconThemeData(
            color: AppColors.kPrimaryForegroundLight,
          ),
          titleTextStyle: GoogleFonts.poppins(
            textStyle: TextStyles.kHeadingStyle.copyWith(
              color: AppColors.kPrimaryForegroundLight,
            ),
          ),
        ),
        iconTheme: const IconThemeData(
          color: AppColors.kForegroundLight,
        ),
        scaffoldBackgroundColor: AppColors.kBackgroundLight,
      );

  static ThemeData darkTheme() => ThemeData(
        brightness: Brightness.dark,
        primaryColor: AppColors.kPrimaryDark,
        colorScheme: ColorScheme.dark(
          primary: AppColors.kPrimaryDark,
          secondary: AppColors.kSecondaryDark,
          surface: AppColors.kBackgroundDark,
          onPrimary: AppColors.kPrimaryForegroundDark,
          onSecondary: AppColors.kSecondaryForegroundDark,
          error: AppColors.kDestructiveDark,
          onError: AppColors.kDestructiveForegroundDark,
          background: AppColors.kBackgroundDark,
          onBackground: AppColors.kForegroundDark,
        ),
        textTheme: TextTheme(
          displaySmall: GoogleFonts.poppins(
            textStyle: TextStyles.kHeadingStyle.copyWith(
              color: AppColors.kForegroundDark,
              fontWeight: FontWeight.bold,
            ),
          ),
          bodyLarge: GoogleFonts.poppins(
            textStyle: TextStyles.kBodyStyle.copyWith(
              color: AppColors.kForegroundDark,
            ),
          ),
          bodyMedium: GoogleFonts.poppins(
            textStyle: TextStyles.kBodyStyle.copyWith(
              fontSize: 14,
              color: AppColors.kForegroundDark,
            ),
          ),
        ),
        inputDecorationTheme: InputDecorationTheme(
          border: AppBorders.kInputBorder,
          filled: true,
          fillColor: AppColors.kMutedDark,
          hintStyle: GoogleFonts.poppins(
            textStyle: TextStyles.kBodyStyle.copyWith(color: AppColors.kMutedForegroundDark),
          ),
        ),
        appBarTheme: AppBarTheme(
          backgroundColor: AppColors.kPrimaryDark,
          elevation: 0,
          iconTheme: const IconThemeData(color: AppColors.kPrimaryForegroundDark),
          titleTextStyle: GoogleFonts.poppins(
            textStyle: TextStyles.kHeadingStyle.copyWith(color: AppColors.kPrimaryForegroundDark),
          ),
        ),
        scaffoldBackgroundColor: AppColors.kBackgroundDark,
        cardColor: AppColors.kSecondaryDark,
        cardTheme: CardTheme(
          color: AppColors.kSecondaryDark,
          elevation: 2,
          margin: EdgeInsets.zero,
        ),
      );
}