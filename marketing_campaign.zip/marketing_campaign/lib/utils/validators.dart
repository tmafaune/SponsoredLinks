class Validators {
  // URL Validation
  static String? validateUrl(String? value) {
    if (value == null || value.isEmpty) {
      return 'URL is required';
    }
    final urlRegex = RegExp(
      r'^(https?:\/\/)?([\w-]+\.)+[\w-]+([\/\?=&#%\.\w-]+)?$',
      caseSensitive: false,
    );
    if (!urlRegex.hasMatch(value)) {
      return 'Enter a valid URL starting with http:// or https://';
    }
    return null;
  }

  // CPC Validation
  static String? validateCPC(String? value) {
    if (value == null || value.isEmpty) {
      return 'CPC amount is required';
    }
    final numericRegex = RegExp(r'^[0-9]+(\.[0-9]{1,2})?$');
    if (!numericRegex.hasMatch(value)) {
      return 'Enter valid amount (e.g. 0.50)';
    }
    final amount = double.tryParse(value);
    if (amount == null || amount <= 0) {
      return 'Amount must be greater than 0';
    }
    return null;
  }

  // Date Validation
  static String? validateDate(DateTime? date) {
    if (date == null) {
      return 'Date is required';
    }
    if (date.isBefore(DateTime.now())) {
      return 'Date cannot be in the past';
    }
    return null;
  }

  // General Required Field Validation
  static String? validateRequired(String? value, String fieldName) {
    if (value == null || value.isEmpty) {
      return '$fieldName is required';
    }
    return null;
  }

  
 

  static String? validateUsername(String? value) {
    if (value == null || value.isEmpty) return 'Username required';
    if (value.length < 4) return 'Minimum 4 characters';
    return null;
  }

  static String? validatePassword(String? value) {
    if (value == null || value.isEmpty) return 'Password required';
    if (value.length < 6) return 'Minimum 6 characters';
    return null;
  }
  // Add other validators as needed...
  }
