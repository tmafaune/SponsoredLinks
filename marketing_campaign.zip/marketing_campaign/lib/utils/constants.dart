// Updated constants.dart
import 'package:flutter/material.dart';

class AppColors {
  // Light Mode Colors
  static const kBackgroundLight = Color(0xFFFFFFFF);
  static const kForegroundLight = Color(0xFF020617);
  static const kPrimaryLight = Color(0xFF0F172A);
  static const kPrimaryForegroundLight = Color(0xFFF8FAFC);
  static const kSecondaryLight = Color(0xFFF1F5F9);
  static const kSecondaryForegroundLight = Color(0xFF0F172A);
  static const kMutedLight = Color(0xFFF1F5F9);
  static const kMutedForegroundLight = Color(0xFF475569);
  static const kAccentLight = Color(0xFFF1F5F9);
  static const kAccentForegroundLight = Color(0xFF0F172A);
  static const kDestructiveLight = Color(0xFFEF4444);
  static const kDestructiveForegroundLight = Color(0xFFF8FAFC);

  // Dark Mode Colors
  static const kBackgroundDark = Color(0xFF020617);
  static const kForegroundDark = Color(0xFFF8FAFC);
  static const kPrimaryDark = Color(0xFFF8FAFC);
  static const kPrimaryForegroundDark = Color(0xFF0F172A);
  static const kSecondaryDark = Color(0xFF1E293B);
  static const kSecondaryForegroundDark = Color(0xFFF8FAFC);
  static const kMutedDark = Color(0xFF1E293B);
  static const kMutedForegroundDark = Color(0xFF94A3B8);
  static const kAccentDark = Color(0xFF1E293B);
  static const kAccentForegroundDark = Color(0xFFF8FAFC);
  static const kDestructiveDark = Color(0xFFB91C1C);
  static const kDestructiveForegroundDark = Color(0xFFF8FAFC);

  // Branding Colors
  static const kOrange = Color(0xFFF97316); // text-orange-500

  // Additional Colors
  static const kGrey = Color(0xFF9E9E9E);
  static const kLightInputBackground = Color(0xFFF5F5F5);
  static const kDarkInputBackground = Color(0xFF2D2D2D);
}

class TextStyles {
  // ... (keep existing text styles, update color references)
  static const kLinkStyle = TextStyle(
    fontSize: 14,
    color: AppColors.kOrange, // Updated to use branding orange
    decoration: TextDecoration.underline,
  );
}

class AppButtons {
  static final kPrimaryButtonStyle = ButtonStyle(
    padding: WidgetStateProperty.all(
      const EdgeInsets.symmetric(vertical: 16, horizontal: 32)),
    shape: WidgetStateProperty.all(
      RoundedRectangleBorder(borderRadius: BorderRadius.circular(12))),
    backgroundColor: WidgetStateProperty.all(AppColors.kPrimaryLight),
    foregroundColor: WidgetStateProperty.all(AppColors.kPrimaryForegroundLight),
  );

  // New orange accent button style
  static final kAccentButtonStyle = ButtonStyle(
    padding: WidgetStateProperty.all(
      const EdgeInsets.symmetric(vertical: 16, horizontal: 32)),
    shape: WidgetStateProperty.all(
      RoundedRectangleBorder(borderRadius: BorderRadius.circular(12))),
    backgroundColor: WidgetStateProperty.all(AppColors.kOrange),
    foregroundColor: WidgetStateProperty.all(Colors.white),
  );
}