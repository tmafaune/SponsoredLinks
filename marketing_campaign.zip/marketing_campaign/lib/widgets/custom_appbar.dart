import 'package:flutter/material.dart';
import 'package:marketing_campaign/utils/constants.dart';
import 'package:go_router/go_router.dart';

class CustomAppBar extends StatelessWidget implements PreferredSizeWidget {
  final String title;
  final bool showBackButton;
  final List<Widget>? actions;

  const CustomAppBar({
    required this.title,
    this.showBackButton = true,
    this.actions,
    super.key,
  });

  @override
  Size get preferredSize => const Size.fromHeight(kToolbarHeight);

  @override
  Widget build(BuildContext context) {
    return AppBar(
      title: Text(
        title,
        style: TextStyles.kHeadingStyle.copyWith(
          color: Theme.of(context).brightness == Brightness.light
              ? Colors.black // Black text in light mode
              : Colors.white, // White text in dark mode
        ),
      ),
      centerTitle: true,
      leading: showBackButton
          ? IconButton(
              icon: Icon(
                Icons.arrow_back,
                color: Theme.of(context).brightness == Brightness.light
                    ? Colors.black // Black icons in light mode
                    : Colors.white, // White icons in dark mode
              ),
              onPressed: () => GoRouter.of(context).pop(), // Use GoRouter for navigation
            )
          : null,
      actions: actions,
      backgroundColor: Theme.of(context).appBarTheme.backgroundColor, // Use theme's AppBar background color
      elevation: 2,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(bottom: Radius.circular(15)),
      ),
    );
  }
}