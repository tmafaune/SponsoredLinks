import 'package:flutter/material.dart';
import 'package:marketing_campaign/models/user_model.dart';
import 'package:provider/provider.dart';
import 'package:go_router/go_router.dart';
import 'package:marketing_campaign/utils/theme.dart';
import 'package:marketing_campaign/services/theme_service.dart';
import 'package:marketing_campaign/views/auth/login_screen.dart';
import 'package:marketing_campaign/views/auth/registration_screen.dart';
import 'package:marketing_campaign/views/profile/create_profile_screen.dart';
import 'package:marketing_campaign/views/dashboard/main_dashboard.dart';
import 'package:marketing_campaign/views/dashboard/campaign_launch_screen.dart';
import 'package:marketing_campaign/views/dashboard/campaign_management.dart';
import 'package:marketing_campaign/views/affiliate/campaign_view_screen.dart';
import 'package:marketing_campaign/views/analytics/analytics_screen.dart';
import 'package:marketing_campaign/views/dashboard/campaign_provider.dart'; // Added this

void main() {
  runApp(
    MultiProvider( // Changed from single provider
      providers: [
        ChangeNotifierProvider(create: (context) => ThemeService()),
        ChangeNotifierProvider(create: (context) => CampaignProvider()), // Added
      ],
      child: const MyApp(),
    ),
  );
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    final themeService = Provider.of<ThemeService>(context);
    final router = GoRouter(
      routes: [
        GoRoute(
          path: '/',
          builder: (context, state) => const LoginScreen(),
        ),
        GoRoute(
          path: '/register',
          builder: (context, state) => const RegistrationScreen(),
        ),
        GoRoute(
          path: '/create-profile',
          builder: (context, state) {
            final registrationData = state.extra as Map<String, dynamic>? ?? {};
            return CreateProfileScreen(registrationData: registrationData);
          },
        ),
        GoRoute(
          path: '/dashboard',
          builder: (context, state) {
            // Pass user data here (replace with actual user provider)
            return DashboardScreen(user: User(name: 'John Doe', contact: 'user@example.com'));
          },
        ),
        GoRoute(
          path: '/launch-campaign',
          builder: (context, state) => const CampaignLaunchScreen(),
        ),
        GoRoute(
          path: '/manage-campaigns',
          builder: (context, state) => CampaignManagementScreen(),
        ),
        GoRoute(
          path: '/analytics',
          builder: (context, state) =>  AnalyticsScreen(),
        ),
        GoRoute(
          path: '/campaign-view/:id',
          builder: (context, state) => CampaignViewScreen(
            campaignId: state.pathParameters['id']!,
          ),
        ),
      ],
      errorBuilder: (context, state) => const LoginScreen(), // Redirect to login on errors
    );
    return MaterialApp.router(
      title: 'Sponsored Links',
      debugShowCheckedModeBanner: false,
      theme: AppTheme.lightTheme(),
      darkTheme: AppTheme.darkTheme(),
      themeMode: themeService.isDarkMode ? ThemeMode.dark : ThemeMode.light,
      routerConfig: router,
    );
  }
}