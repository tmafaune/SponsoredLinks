class User {
  final String name;
  final String contact;

  const User({required this.name, required this.contact});
}