import 'package:intl/intl.dart';
import 'dart:io';  // Add this import for File

class Campaign {
  final String id;
  final String title;
  final String ownerName;
  final String bannerUrl;
  final String landingUrl;
  final File? bannerImage;  // Add this
  final double cpc;
  final double budget;
  final DateTime startDate;
  final DateTime endDate;

  Campaign({
    required this.id,
    required this.title,
    required this.ownerName,
    required this.bannerUrl,
    required this.landingUrl,
    this.bannerImage,  // Add this (optional parameter)
    required this.cpc,
    required this.budget,
    required this.startDate,
    required this.endDate,
  });

  String get formattedStartDate => DateFormat('MMM d, yyyy').format(startDate);
  String get formattedEndDate => DateFormat('MMM d, yyyy').format(endDate);

  factory Campaign.fromJson(Map<String, dynamic> json) {
    return Campaign(
      id: json['id'] as String,
      title: json['title'] as String,
      ownerName: json['ownerName'] as String,
      bannerUrl: json['bannerUrl'] as String,
      landingUrl: json['landingUrl'] as String,
      bannerImage: json['bannerImage'] != null 
          ? File(json['bannerImage'] as String) 
          : null,  // Add this
      cpc: (json['cpc'] as num).toDouble(),
      budget: (json['budget'] as num).toDouble(),
      startDate: DateTime.parse(json['startDate'] as String),
      endDate: DateTime.parse(json['endDate'] as String),
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'title': title,
      'ownerName': ownerName,
      'bannerUrl': bannerUrl,
      'landingUrl': landingUrl,
      'bannerImage': bannerImage?.path,  // Add this
      'cpc': cpc,
      'budget': budget,
      'startDate': startDate.toIso8601String(),
      'endDate': endDate.toIso8601String(),
    };
  }
}
