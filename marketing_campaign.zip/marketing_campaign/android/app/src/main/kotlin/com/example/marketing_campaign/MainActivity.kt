package com.example.marketing_campaign

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
